package server;

public class StartServer {
    public static void main(String[] args) {
        new Server();
    }
}
